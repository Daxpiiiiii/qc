var C='qc-pre-alpha-1-v1';
var A=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png'];
self.addEventListener('install',function(e){
e.waitUntil(caches.open(C).then(function(c){return c.addAll(A);}).then(function(){return self.skipWaiting();}));
});
self.addEventListener('activate',function(e){
e.waitUntil(caches.keys().then(function(k){return Promise.all(k.filter(function(n){return n!==C;}).map(function(n){return caches.delete(n);}));}).then(function(){return self.clients.claim();}));
});
self.addEventListener('fetch',function(e){
if(e.request.method!=='GET')return;
e.respondWith(caches.match(e.request).then(function(r){
return r||fetch(e.request).catch(function(){return caches.match('./index.html');});
}));
});
